from __future__ import print_function

from mpl_toolkits.mplot3d import axes3d
import matplotlib.pyplot as plt
import numpy as np
import time

RX = 36
TX = 18

class Plot_flow():

    def __init__ (self):

        print ("Plot 3D")

        self.fig = None
        self.ax = None
        
        # Make the X, Y meshgrid.
        xs = np.linspace(0, TX - 1, TX)
        ys = np.linspace(0, RX - 1, RX)
        self.X, self.Y = np.meshgrid(xs, ys)
        
        self.wframe = None
        
    def plot_function(self, frame_array):
        if self.fig == None:
            self.fig = plt.figure()
            self.ax = self.fig.add_subplot(111, projection='3d')
        
        # If a line collection is already remove it before drawing.
        if self.wframe:
            self.ax.collections.remove(self.wframe)

        self.wframe = self.ax.plot_wireframe(self.X, self.Y, frame_array, rstride = 1, cstride = 1) #rstride & cstride -> Downsampling 
        plt.pause(.001)
        #self.fig.waitforbuttonpress()
        #plt.show()

    def close(self):
        plt.close()
        self.fig = None
        self.ax = None
    
def Rawdata_plot_mechanism(filename = None):
    frame_array = None
    frame_list = []
    plt_obj = Plot_flow()
    
    with open(filename, 'r') as f:
        for line in f.readlines():

            #Split to single data
            data_row = line.split()
            assign_list = []
            
            #Transfer data to int data only
            for data in data_row:
                try:
                    assign_list.append(int(data))
                except:
                    pass
                         
            #Change type as np.array
            if len(assign_list) != 0:
                if len(assign_list) > TX:
                    assign_list.pop()
                frame_list.append(assign_list)
                
            #Plot
            if len(assign_list) == 0 and frame_list != []:
                if len(frame_list) > RX:
                    frame_list.pop()
                frame_array = np.array(frame_list)
                #print (frame_array)
                plt_obj.plot_function(frame_array)
                frame_list = []

    plt_obj.close()
    
def main():
    Rawdata_plot_mechanism("20190625_11-02-26.txt")

if __name__ == "__main__":
    main()
